
# Kraken Bot Main File
import os, time, threading, hmac, hashlib, base64, requests
from urllib.parse import urlencode
from datetime import datetime
import json

KRAKEN_API_KEY = os.getenv("KRAKEN_API_KEY")
KRAKEN_API_SECRET = os.getenv("KRAKEN_API_SECRET")
TRADE_AMOUNT = 5
STOP_LOSS = 0.002
TAKE_PROFIT = 0.015

LOG_FILE = "trade_log.json"
BAD_PAIRS_FILE = "bad_pairs.json"

def init_logs():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w") as f: json.dump({"wins":0,"losses":0,"total_profit":0,"trades":[],"order_logs":[]}, f)
    if not os.path.exists(BAD_PAIRS_FILE):
        with open(BAD_PAIRS_FILE, "w") as f: json.dump([], f)
init_logs()

def log_trade(pair, result, profit):
    with open(LOG_FILE) as f: data = json.load(f)
    data["trades"].append({"time": datetime.utcnow().isoformat(), "pair": pair, "result": result, "profit": profit})
    data["wins"] += int(result == "win")
    data["losses"] += int(result == "loss")
    data["total_profit"] += profit
    with open(LOG_FILE, "w") as f: json.dump(data, f)

def log_order(order): 
    with open(LOG_FILE) as f: data = json.load(f)
    data["order_logs"].append(order)
    data["order_logs"] = data["order_logs"][-50:]
    with open(LOG_FILE, "w") as f: json.dump(data, f)

def mark_bad(pair): 
    with open(BAD_PAIRS_FILE) as f: bad = json.load(f)
    if pair not in bad:
        bad.append(pair)
        with open(BAD_PAIRS_FILE, "w") as f: json.dump(bad, f)

def is_bad(pair): 
    with open(BAD_PAIRS_FILE) as f: return pair in json.load(f)

def kraken_request(endpoint, data=None, private=False):
    url = 'https://api.kraken.com'
    path = f'/0/{"private" if private else "public"}/{endpoint}'
    headers, data = {}, data or {}
    if private:
        nonce = str(int(time.time() * 1000))
        data['nonce'] = nonce
        postdata = urlencode(data)
        message = (nonce + postdata).encode()
        sha256 = hashlib.sha256(message).digest()
        sig = hmac.new(base64.b64decode(KRAKEN_API_SECRET), path.encode() + sha256, hashlib.sha512)
        headers = {
            'API-Key': KRAKEN_API_KEY,
            'API-Sign': base64.b64encode(sig.digest()).decode()
        }
        return requests.post(url+path, headers=headers, data=data).json()
    else:
        return requests.get(url+path, params=data).json()

def get_ticker(pair):
    try: return float(kraken_request("Ticker", {"pair": pair})["result"][pair]["c"][0])
    except: return None

def place_order(pair, side, vol):
    res = kraken_request("AddOrder", {"pair": pair, "type": side, "ordertype": "market", "volume": vol}, True)
    log_order({"time": str(datetime.utcnow()), "pair": pair, "vol": vol, "side": side, "response": res})
    return res

def convert_to_usd(pair, vol):
    base = pair.replace("USD", "")
    return place_order(f"{base}USD", "sell", vol)

def get_pairs():
    assets = kraken_request("AssetPairs").get("result", {})
    pairs = []
    for pair, info in assets.items():
        if ".d" in pair or not pair.endswith("USD"): continue
        if is_bad(pair): continue
        try:
            price = get_ticker(pair)
            if not price: continue
            vol = round(TRADE_AMOUNT / price, 6)
            test = kraken_request("AddOrder", {
                "pair": pair, "type": "buy", "ordertype": "market", "volume": vol, "validate": True
            }, True)
            if not test.get("error"): pairs.append(pair)
            else: mark_bad(pair)
        except: mark_bad(pair)
    return pairs

def is_uptrend(pair):
    prices = []
    for _ in range(4):
        p = get_ticker(pair)
        if p: prices.append(p)
        time.sleep(1)
    return len(prices) >= 4 and (prices[-1] - prices[0]) / prices[0] > 0.0005

def trade_loop():
    pairs = get_pairs()
    print(f"Bot live: {datetime.utcnow()} | Scanning {len(pairs)} pairs")
    while True:
        for pair in pairs:
            try:
                if not is_uptrend(pair): continue
                price = get_ticker(pair)
                if not price: continue
                vol = round(TRADE_AMOUNT / price, 6)
                buy = place_order(pair, "buy", vol)
                buy_price = price
                stop = price * (1 - STOP_LOSS)
                target = price * (1 + TAKE_PROFIT)
                while True:
                    price = get_ticker(pair)
                    if price <= stop:
                        log_trade(pair, "loss", -TRADE_AMOUNT * STOP_LOSS)
                        break
                    if price >= target:
                        place_order(pair, "sell", vol)
                        profit = TRADE_AMOUNT * (target / buy_price - 1)
                        log_trade(pair, "win", profit)
                        break
                    time.sleep(2)
                convert_to_usd(pair, vol)
            except Exception as e:
                log_order({"error": str(e), "pair": pair})
                mark_bad(pair)
        time.sleep(2)

threading.Thread(target=trade_loop).start()
