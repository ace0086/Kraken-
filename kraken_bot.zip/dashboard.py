
from fastapi import FastAPI
import json

app = FastAPI()

@app.get("/")
def root():
    with open("trade_log.json") as f:
        return json.load(f)
